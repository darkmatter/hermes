# Pitfall: macOS Keychain Hangs

When executing `gog` CLI commands in the background (especially `gog gmail` or `gog auth` commands) on macOS, the command may hang indefinitely or time out. 

**Root Cause:**
The `gog` CLI stores OAuth tokens in the macOS Keychain. Occasionally, macOS will prompt the user with a UI dialog requesting permission to access the Keychain item. Because the agent is running in the background without UI access, the CLI waits forever.

**Resolution:**
Do not attempt to bypass this with file-backed configurations unless starting from scratch. Instead:
1. Ask the user to open a local terminal window on their machine.
2. Guide them to run: `gog auth list`
3. Instruct them to click **"Always Allow"** on the macOS Keychain UI prompt.
4. Once they confirm, resume background `gog` operations.