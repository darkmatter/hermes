---
name: gog
description: Google workspace CLI (gog) for Gmail, Calendar, Drive, Chat, and more. Auth, email triage, and day-to-day Google operations.
version: 0.1.0
triggers:
  - gog
  - gmail
  - google mail
  - google calendar
  - google drive
  - email digest
  - email triage
---

# gog — Google Workspace CLI

## Overview

**gog** (v0.21.0, Homebrew) is a full-featured CLI for Google services: Gmail, Calendar, Drive, Chat, Contacts, Tasks, Sheets, Docs, YouTube, and more.

**Binary:** `gog` (Homebrew)
**Account:** `cooper@darkmatter.io`
**OAuth client:** stored in himitsu as `google/oauth-client-secret-darkmatter-drive.json`
**Config:** `~/.config/gogcli/config.json`
**Credentials:** `~/.local/share/gogcli/credentials.json` + keyring

## Authentication

### Status check
```bash
gog status          # Shows account, client, keyring backend, credential paths
```

### Re-authorize (add scopes)
When you get `unauthorized_client` errors, the refresh token lacks the needed scope. Re-auth with:
```bash
gog login cooper@darkmatter.io --services=gmail,calendar,drive --gmail-scope=full --force-consent
```

### Headless / CLI-agent auth flow

When no interactive browser popup works (e.g. in a terminal agent session), use the two-step remote flow:

**Step 1 — print the auth URL:**
```bash
gog login cooper@darkmatter.io --services=gmail,calendar,drive --gmail-scope=full --force-consent --remote --step 1
```
This outputs a URL. The user opens it in their browser and authorizes.

**Step 2 — exchange the redirect code:**
After authorization, the browser redirects to a `127.0.0.1` URL that won't load. The user copies that full URL and provides it:
```bash
gog login cooper@darkmatter.io --services=gmail,calendar,drive --force-consent --remote --step 2 --auth-url "<redirect-url-from-browser>"
```

**Alternative: manual flow** (paste redirect URL inline):
```bash
gog login cooper@darkmatter.io --services=gmail --gmail-scope=full --force-consent --manual
```
This prints a URL and waits for you to paste the redirect URL back.

### Services and scopes

- `--services=gmail` — Gmail only
- `--services=gmail,calendar,drive` — Multiple services at once
- `--services=all-user` — All user OAuth services
- `--gmail-scope=full` — Read + modify + send
- `--gmail-scope=readonly` — Read only
- `--drive-scope=full|readonly|file` — Drive scope modes
- `--readonly` — Use read-only scopes for all services
- `--force-consent` — Required when re-authing to add new scopes

## Gmail

```bash
# List / search messages
gog gmail list "in:inbox newer_than:1d" -j --max 20       # Recent inbox (JSON)
gog gmail list "from:someone@example.com" -j --max 10      # From a sender
gog gmail list "subject:urgent is:unread" -j               # Unread with subject

# Read a message
gog gmail read <message-id> -j                              # Full message (JSON)
gog gmail read <message-id> -p                              # Plain text

# Send email
gog gmail send --to "user@example.com" --subject "Subject" --body "Body text"
gog gmail send --help                                       # All send options

# Labels
gog gmail labels list -j                                    # List all labels

# Threads
gog gmail thread <thread-id> -j                             # Read a thread

# Modify
gog gmail modify <message-id> --add-labels IMPORTANT --remove-labels INBOX
gog gmail trash <message-id>
```

### Safety flag
```bash
--gmail-no-send    # Block Gmail send operations (agent safety)
```

## Calendar

```bash
gog calendar list -j --max 10                              # Upcoming events
gog calendar today -j                                      # Today's events
gog calendar create --summary "Meeting" --start "2025-07-15T10:00:00" --end "2025-07-15T11:00:00"
```

## Drive

```bash
gog drive ls -j                                            # List files
gog drive search "query" -j                                # Search files
gog drive download <file-id>                               # Download a file
gog drive upload <local-path>                              # Upload a file
gog open <file-id>                                         # Open in browser
```

## Output formats

- `-j` / `--json` — JSON output (best for scripting)
- `-p` / `--plain` — TSV/plain text (parseable, no colors)
- `--results-only` — JSON mode: emit only primary result (drop envelope fields)
- `--select=field1,field2` — JSON mode: select specific fields

## Common patterns

- **macOS Keychain blocking**: Background jobs or agent queries will hang if standard macOS permissions prompt for Keychain access. [See `references/macos-keychain-pitfall.md` for mitigation.]

### Email triage digest

### Email triage digest

```bash
# Get today's unread inbox messages as JSON
gog gmail list "in:inbox is:unread newer_than:1d" -j --max 50
```

### Triaging a large inbox (hundreds–thousands of threads)

For "triage my email for the last N days", inboxes can be 800–1200+ threads. Proven workflow:

1. **Paginate with `--all`, NOT `--page-token`** — `gog gmail list` has NO `--page-token` flag (it's `--page`, but `--all` is simpler). Use `gog gmail list "in:inbox newer_than:30d" -j --all`.
2. **Redirect to a file — do NOT capture inline in execute_code.** A 30-day inbox JSON is 250KB–410KB; the execute_code stdout cap (~20KB) truncates it mid-JSON and `json.loads` fails. Write it from the terminal first: `gog gmail list "in:inbox newer_than:30d" -a <acct> -j --all > /tmp/<acct>_inbox.json`, then load and process the file in execute_code.
3. **Classify, don't dump.** 95% of these inboxes are unread automated noise. Parse `from`, `subject`, and `labels` (CATEGORY_* + UNREAD) and bucket into: human correspondence, financial/account action-signals, security/fraud alerts, work-system notifications, promotions, and bulk noise. Regex an ACTION pattern (`due|overdue|failed|declined|action required|verify|confirm|fraud|suspicious|expir|renew|statement|payment|transfer`) over subjects to surface what actually needs the user. Maintain a small set of known human/colleague senders to separate real people from `noreply@`/`notify.`/`newsletter@` traffic.
4. **Report by priority bucket** (urgent/deadline → people/replies → cleanup), not chronologically. Identify the single biggest noise sender (often shows up 70–113×) as the cleanup target.
5. Pulling action items onto a board afterward → see the `hermes-kanban` skill (create with `--triage` to land them in the triage column).
# Last 30 days unread primary inbox
gog gmail list "in:inbox is:unread category:primary newer_than:30d" -j --max 100

# Low-signal bulk (promotions + social, older than 7 days)
gog gmail list "(category:promotions OR category:social) older_than:7d" -j --max 100
```

When triaging, always use `--gmail-no-send` to prevent accidental sends:
```bash
gog --gmail-no-send gmail list "in:inbox newer_than:30d" -j --max 100
```

### Quick profile check
```bash
gog whoami -j       # Show authenticated user profile
```

## Pitfalls

- **`--remote --step 2` HANGS in foreground agent sessions** — run the exchange as a BACKGROUND process, not foreground. Run foreground, it blocks past the timeout and the single-use auth code gets consumed without persisting, forcing a fresh `--step 1`. Fix: launch step 2 with `background=true` (+ `notify_on_complete=true`), then `process(action='wait')` for it. It completes in a few seconds and prints `email\t<addr>\nservices\tgmail\nclient\tdefault` on success.
- **Wrong-account authorization** — the redirect URL carries `hd=<domain>`. Before running step 2, confirm `hd=` matches the account you're adding (e.g. `hd=cm.xyz` for me@cm.xyz). If Google defaulted to a different signed-in account, gog rejects it with `authorized as X, expected Y` and nothing saves. Tell the user explicitly: on the Google account picker choose the TARGET account / "Use another account", since Google auto-selects the last-used one.
- **macOS Keychain permission prompt on first token read** — the first `gog gmail ...` call for a newly-added account triggers a macOS Keychain dialog and the call fails with `keyring connection timed out after 10s ... (macOS Keychain may be waiting for a permission prompt)`. The user must click **Always Allow** on the dialog; then retry — it works. This is a one-time per-account GUI gate, not a gog bug.
- **Multi-account triage** — different gog accounts are independent OAuth grants. Run each through its own `--step 1`/`--step 2`. Target a specific account on any command with `-a <email>` (e.g. `gog gmail list "in:inbox newer_than:30d" -a me@cm.xyz -j --all`).
- **Scope errors appear as `unauthorized_client`/`Unauthorized`** — the refresh token was granted for different scopes. Fix with `gog login ... --force-consent` and include all needed `--services`.
- **`Gmail API is not enabled for this OAuth project`** (exit 6) — the project (e.g. darkmatter-471021, client_id prefix 312090722439) needs the Gmail API enabled in Google Cloud Console. There's no gcloud here; have the user click Enable at the console URL gog prints, then retry. Not a code fix.
- **Browser auth may time out in agent sessions** — use `--remote --step 1` / `--step 2` flow instead.
- **`--force-consent` is required** when adding new scopes to an existing token; without it Google returns the old token with its original scopes.
- **`--gmail-no-send`** is a safety flag that blocks send operations — useful for read-only triage agents.
- **`gog gmail list` requires a query argument** — it's not `gog gmail list` but `gog gmail list "in:inbox"`.
- **`gog gmail show` or `gog gmail list` timeout**: macOS Keychain may trigger a hidden GUI permission prompt. Run `gog auth list` in a *local user terminal* and click "Always Allow" in the GUI prompt to unblock back-ground queries. Do NOT attempt to use browser-automation as a workaround for blocked `gog` CLI access; ask the user to authorize the Keychain.
- **`gog gmail labels`** is not a valid subcommand — use `gog gmail labels list` instead.
- **Gmail API must be enabled on the GCP project** — even after successful auth, Gmail commands fail with "Gmail API is not enabled for this OAuth project" if the API isn't activated. Fix: direct user to `https://console.cloud.google.com/apis/api/gmail.googleapis.com/overview?project=<PROJECT_ID>` to enable it. This is a prerequisite distinct from auth/scope errors. Same applies for other services (Calendar, Drive, etc.) — each API must be enabled separately in the GCP console.
- **`--manual` auth flow does NOT work in agent sessions** — it opens a PTY that blocks waiting for stdin input and cannot be satisfied programmatically. Always use `--remote --step 1` / `--step 2` instead. Never fall back to `--manual` in agent contexts.
- **Agent-session auth: present the URL once and wait** — when auth fails in a non-interactive session, run `--remote --step 1`, give the user the URL, and stop. Don't re-try or chain `--manual` as a fallback; each attempt generates a new state and confuses the flow. One clear ask, one response.
- **`--remote --step 2` can hang/timeout, and the auth code is single-use** — sometimes the step-2 exchange blocks (>20s) and does NOT persist the token. Symptoms: command times out, then `gog gmail list -a <email>` reports "No auth for gmail <email>". The redirect `code=` is consumed by the failed attempt, so you CANNOT just re-run step 2 with the same URL. Recovery: run `--remote --step 1` again to mint a fresh URL+state, have the user re-authorize, and exchange the new redirect. ALWAYS verify success with `gog auth list -p` (shows account, client, services, token timestamp) before declaring auth done — don't trust a silent/timed-out step 2.
- **Run step 2 in the BACKGROUND to avoid the foreground hang** — the proven fix: launch the `--remote --step 2` exchange with `terminal(background=true, notify_on_complete=true)`, then `process(action='wait', timeout=25)`. It completes in a couple seconds normally; the background harness means a hang can't block your turn, and you still capture the exit status + output. Do NOT run step 2 as a plain foreground command — that's what hangs.
- **Account mismatch: gog validates authorized account == requested account** — if you run `gog login me@cm.xyz ... --step 2` but the user authorized with a DIFFERENT Google account (because the account picker defaulted to another logged-in account), step 2 fails with `authorized as <other>, expected me@cm.xyz` and nothing is saved. EARLY DETECTION: the redirect URL carries an `hd=<domain>` param — check it matches the target account's domain before exchanging (e.g. `hd=darkmatter.io` when you asked for an `@cm.xyz` account = wrong account, will fail). PREVENTION: when handing the user the step-1 URL, explicitly tell them to pick the correct account on Google's chooser ("Use another account" if it auto-signs into the wrong one). Recovery is the same single-use-code path: mint a fresh URL via step 1 and retry with the right account.
- **Adding a second account reuses the same OAuth client** — `gog login <other@email> --services=gmail ...` works fine for multi-account; each account gets its own token bucket under the shared `default` client. The Gmail API enable step (below) is per-GCP-project, so once enabled it covers all accounts on that client.

## Cross-references

- OAuth client secret lives in himitsu: `google/oauth-client-secret-darkmatter-drive.json`
- See the `himitsu` skill for reading/writing that secret
