# macOS Keychain Background Blocking

When running `gog` commands (like `gog auth list`, `gog gmail list`, `gog gmail show`) that necessitate access to OAuth tokens stored in the macOS Keychain, the command may hang or timeout if it runs in the background.

**The Problem:** 
macOS raises a UI prompt for Keychain access ("gog wants to access key..."). Because the terminal is executing via the agent background loop (or a non-interactive shell), this UI prompt cannot be viewed or accepted blindly. The command will block until the wrapper's timeout kills it (frequently `exit code 124` after 10-30s).

**The Fix:** 
Instruct the user to open a local foreground terminal, explicitly run `gog auth list`, and click "Always Allow" in the macOS Keychain prompt window that appears. Once they approve this locally, subsequent background `gog` commands will succeed seamlessly without timing out.