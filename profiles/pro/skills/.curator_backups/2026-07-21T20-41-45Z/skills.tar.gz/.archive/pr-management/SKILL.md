---
name: pr-management
description: Reviewing, triaging, and merging GitHub Pull Requests, including querying CI status and handling Graphite (gt) stacks and merge queues.
---

# Pull Request Management

Use this skill when tasked with summarizing, triaging, or merging open pull requests (PRs).

## Triaging and Summarizing PRs

When asked to summarize or triage multiple open PRs, doing so via the standard GitHub CLI (`gh pr list`) often omits crucial CI check details or swamps the context window with raw JSON data.

**Best Practice:**
Use a Python script (via `execute_code` or `terminal`) to iterate over the PR numbers, run `gh pr view <number> --json statusCheckRollup,comments,reviews`, and parse the output into a concise summary.

**Pitfall - GitHub API Inconsistencies:**
When parsing the `statusCheckRollup` field, GitHub's GraphQL API is highly variable between different types of checks (GitHub Actions vs third-party integrations). A check's outcome might be stored in `conclusion`, `state`, or `status`. Map them gracefully to avoid missing failures:
```python
conclusion = check.get('conclusion') or check.get('state') or check.get('status') or 'UNKNOWN'
status = check.get('status')
name = check.get('name') or check.get('context') or check.get('__typename')
```
Summarize the counts of `SUCCESS`, `FAILURE`, and `PENDING` states so the user gets a high-level health read of the PRs.

## Merging and Graphite (gt) Stacks

When asked to merge PRs, pay attention to the repository settings and stack dependencies (especially for stacks authored via Graphite).

### 1. Merge Queues
If the repository has a merge queue enabled, direct branch merging (e.g., `gh pr merge --squash`) will fail with the error: *"The merge strategy ... is set by the merge queue"*.
**Solution:** You MUST use the `--auto` flag to enqueue the PR (e.g., `gh pr merge --auto --squash`).

### 2. Graphite Stacks (`gt merge`)
When merging a stack of PRs via Graphite:
1. Try running `gt sync --force` and `gt restack` to pull in remote dependencies and ensure the stack is fresh on `origin/develop`.
2. Run `gt merge` (or `gt merge --dry-run` to preview).
3. **Pitfall - Merge Conflicts:** If `gt restack` fails due to merge conflicts on an intermediate branch, do not attempt to guess or force the resolution. Abort the rebasing (`git rebase --abort`), switch back to the original branch, and notify the user to resolve the conflicts manually.
4. **Pitfall - Merge Queue Blocking:** If the bottom-most PR is added to the merge queue, `gt merge` will refuse to merge the rest of the stack until the first PR is officially merged into the trunk. **Do not create infinite sleep/poll loops** waiting for the queue to drain. Enqueue the base PR and inform the user that the downstack is blocked until the queue finishes processing.