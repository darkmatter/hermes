# Live Chrome CDP Workflow (macOS)

For authenticated sessions (banks, MFA-gated portals, passkeys), the user prefers using their existing live local Chrome profile via Chrome DevTools Protocol (CDP) on `127.0.0.1:9222`, rather than isolated headless browsers like Camofox.

## Usage Rules
1. **Privacy:** Do NOT dump existing tab URLs, titles, or page contents unless explicitly requested.
2. **Isolation:** Always open a new tab (`navigate` or `newtab` in CDP) for agent actions.
3. **Action Gating:** The live profile has high privileges. All terminal submissions (clicks that submit forms, authorize payments, rotate keys, etc.) MUST be explicitly authorized by the user before execution. Read-only navigation and DOM inspection are safe.
4. **Connection:** Connect locally using `chrome-remote-interface` or similar CDP clients to `127.0.0.1:9222`.

*Note: A custom JS helper proxy generally resides in the user's `$HOME/.hermes/scripts/live-chrome-cdp.js` for safe interaction.*