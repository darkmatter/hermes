# Dependency Mapping for Autonomous Email Triage

Use this reference when moving from one-off email triage to reliable delegated/autonomous operation.

## Session learning

Cooper corrected the sequence: before an agent starts working triage cards autonomously, it should define what `done` means for every task and identify dependencies requiring Cooper. This avoids false progress and surprise interruptions.

## Required setup before execution

For each card, record:

1. **DoD class** — INVESTIGATE, DRAFT, EXECUTE-SAFE, EXECUTE-GATED, or HANDOFF.
2. **Gherkin scenario** — card-specific Given/When/Then acceptance criteria.
3. **Dependency note** — what blocks the agent from completion, especially accounts/logins/2FA/identity/payment decisions.
4. **Evidence check** — exact query, artifact, API read-back, or Cooper confirmation needed to close.

## Dependency categories

- **No Cooper dependency:** existing Gmail/kanban access is enough; agent can close if DoD evidence passes.
- **Cooper approval:** agent can prepare/draft; action needs approval before sending, spending, deleting, rotating, or applying external side effects.
- **Cooper login / identity:** official account login, passkey/2FA, phone call, or personal identity verification is required.
- **Cooper decision:** judgment only Cooper can make (pay/renew/accept/decline/confirm intent).

## Common account clusters

Batch Cooper interventions by cluster rather than interrupting card-by-card:

- **Financial/security:** Bank of America, Amex, Capital One, Brex, Coinbase, Stripe.
- **Business ops:** Parafin, Gusto, tax accountant/IRS/payment portal, Saltbox.
- **Dev/security:** GitHub org security alerts, Composio, Google/Workspace, exchange/security-login alerts.
- **Real estate/logistics:** contractors, shipping, property management, calendar scheduling.

## Operating pattern

1. Agent annotates all cards with DoD + Gherkin + dependency notes.
2. Agent works INVESTIGATE and DRAFT cards first to reduce ambiguity.
3. Agent converts HANDOFF cards into concise briefs: account/app to open, exact action, success criteria.
4. Agent batches Cooper prompts by dependency cluster.
5. Over time, replace repeated HANDOFFs with safe OAuth/API/read-only access where possible; keep write/payment/security actions gated.

## Pitfalls

- Do not start executing just because a card looks actionable; first define the closing test.
- Do not mark HANDOFF cards done after writing a brief; Cooper is the closer unless he delegates the exact action.
- Do not treat login access as approval for side effects. Access enables investigation; approval gates writes, payments, sends, deletes, rotations.
- For bank/fraud emails, never click email verification links. Brief Cooper to use the official app or phone number from the physical card.
