Feature: Reliable autonomous email triage
  As Cooper
  I want every inbox-triage task to have a verifiable Definition of Done
  So that the agent can work autonomously without closing work based on vibes

  Rule: A card cannot be closed without observable evidence

    Scenario: Reject closing a card based only on the agent's assertion
      Given a kanban card in the email-triage board
      And the card has no attached verification evidence
      When the agent believes the task is complete
      Then the agent must not move the card to done
      And the agent must attach the missing evidence or move the card to review or blocked

  Rule: INVESTIGATE tasks close with a finding and recommendation

    Scenario: Complete an INVESTIGATE card
      Given a triage card classified as INVESTIGATE
      When the agent has read the relevant email/thread/source
      Then the agent comments with what was found
      And the comment includes risk or priority
      And the comment includes a recommended next action
      And the agent may move the card to done

  Rule: DRAFT tasks stop for review

    Scenario: Complete a DRAFT card
      Given a triage card classified as DRAFT
      When the agent has prepared the proposed response, filter, or plan
      Then the agent comments with the complete draft
      And the agent moves the card to review
      And the agent does not send, publish, or apply the draft

  Rule: EXECUTE-SAFE tasks require read-back verification

    Scenario: Complete an EXECUTE-SAFE card
      Given a triage card classified as EXECUTE-SAFE
      And the action is reversible and inbox-only
      When the agent performs the action
      Then the agent runs a verifying query or API read-back
      And the agent comments with the exact command/query and result count
      And the agent may move the card to done only if the result matches the Done condition

  Rule: EXECUTE-GATED tasks require Cooper approval before side effects

    Scenario: Complete an EXECUTE-GATED card
      Given a triage card classified as EXECUTE-GATED
      And the action sends a message, spends money, deletes data, rotates credentials, or has legal/security weight
      When the agent has enough information to act
      Then the agent asks Cooper for approval at the gate
      And the agent does not act before approval
      When Cooper approves the specific action
      Then the agent performs only the approved action
      And the agent verifies the side effect with a read-back
      And the agent comments with the approval, action taken, and verification evidence

  Rule: HANDOFF tasks become complete briefs for Cooper

    Scenario: Complete a HANDOFF card
      Given a triage card classified as HANDOFF
      And the task requires Cooper's identity, phone call, passkey, 2FA, in-person presence, or judgment
      When the agent has gathered the relevant context
      Then the agent comments with a complete handoff brief
      And the brief includes the account, last-four or identifier, contact method, what to say/do, and success criteria
      And the agent moves the card to blocked
      And Cooper remains the closer of the card

  Rule: Bank fraud links are never clicked by the agent

    Scenario: Stage a bank fraud alert for handoff
      Given an email asks the recipient to verify suspicious activity through email links
      When the agent reads the email
      Then the agent must not click Yes, No, Sign in, or Verify links from the email
      And the agent classifies the card as HANDOFF
      And the agent tells Cooper to call the number on the physical card or use the official app
