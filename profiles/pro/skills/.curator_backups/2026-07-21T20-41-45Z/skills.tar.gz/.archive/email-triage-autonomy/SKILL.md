---
name: email-triage-autonomy
description: Run autonomous email/inbox triage for Cooper with a Definition-of-Done contract. Use when triaging Gmail, working an email-triage kanban board, or deciding what email actions can be done autonomously vs gated to the user. Pairs with the gog skill.
version: 0.1.0
triggers:
  - triage my email
  - email triage
  - work the triage board
  - inbox cleanup
---

# Email Triage Autonomy

Autonomous inbox triage with a reliability contract. The goal is for the agent to
eventually handle email end-to-end while guaranteeing nothing irreversible happens
without a gate.

## Canonical framework

Read first: `~/.hermes/email-triage-dod-framework.md` (the Definition-of-Done classes,
evidence rules, and card bookkeeping). It is the source of truth; this skill is the
operational wrapper.

## Workflow

1. **Auth & pull** — use the `gog` skill. Pull `in:inbox newer_than:30d -j --all` per
   account to a temp file (output > 20KB gets truncated by the code tool; write to file,
   parse with Python). gog Gmail API project = darkmatter-471021; keychain may prompt
   once per new account (user clicks Allow).
2. **Classify into buckets** — financial/action, real-human correspondence, security/
   fraud, bulk noise. De-noise hard: noreply/notify/newsletter/digest/auctions patterns.
3. **Board** — create/use the `email-triage` kanban board
   (`hermes kanban --board email-triage ...`). Cards created with `--triage` land in the
   `triage` status column. Prefix personal-account cards with `[cm.xyz]` to distinguish
   from work (`darkmatter`) cards.
4. **Before executing anything, make cards closeable.** Cooper's preferred sequence is:
   define what `done` means first, then identify dependencies that require him, then work
   the board. Do not start autonomous execution on a card whose closing test is still vague.
4. **Assign a DoD class to every card** (INVESTIGATE / DRAFT / EXECUTE-SAFE /
   EXECUTE-GATED / HANDOFF).
   **USER PREFERENCE / CRITICAL CORRECTION**: The Definition of Done literally means *fully resolved in the real world*. A HANDOFF to Cooper must NEVER be considered "done" just because the brief was staged. Leave handoff tasks `blocked` until Cooper completes them and you can objectively verify the state change.
   `DoD-CLASS: <CLASS> | DONE: <condition> | CHECK: <verifying query>`.
   Also include a card-specific Gherkin scenario (`Scenario: ...`, `Given/When/Then`)
   derived from `templates/email-triage-dod.feature` so the acceptance criteria are
   executable-style and human-readable.
6. **Map dependencies for every card.** Add a `DEPENDENCY:` comment naming required
   accounts, logins, 2FA/passkeys, Cooper approvals, phone calls, payment authority, or
   human judgment. Use `references/dependency-mapping.md` for categories and batching.
7. **For authenticated account work, establish the access path before acting.** For banks,
   passkey-heavy sites, and local-device-trust workflows, use Cooper's live local Chrome
   via CDP rather than remote Camofox. Use `references/live-chrome-cdp-financial-login.md`.
   Credential path: himitsu `op-service-account/token` → 1Password service account → live
   Chrome CDP. Get as far as username/password login autonomously. If SMS OTP is the next
   challenge and Cooper has authorized login automation for that account, use BlueBubbles /
   local Messages per `references/bluebubbles-otp-for-logins.md` to retrieve and enter the
   code. Stop at passkey/phone approval/security question/device-trust/fraud/payment/settings
   decisions and comment the blocker.
8. **Work the board by class:**
   - INVESTIGATE → read bodies, post finding+recommendation comment, close.
   - EXECUTE-SAFE → act, run verifying gmail query, paste count, close.
   - DRAFT → stage draft on card, move to `review`, stop.
   - EXECUTE-GATED → clarify() at the gate, act only after approval, verify side-effect.
   - HANDOFF → write complete brief (number/URL/last-4/what-to-say), set `blocked`,
     owner=Cooper. Never auto-click "verify" links in bank/fraud emails (phishing-shaped).
9. **Never** mark `done` without observable evidence (re-runnable gmail query, artifact
   on disk, API state read). The agent's own assertion is not evidence.

## Decision shortcut (which class)

call/passkey/identity needed → HANDOFF; money/outbound-message/delete/security → GATED;
reversible inbox-only change → EXECUTE-SAFE; produces something to approve → DRAFT;
just find-out+recommend → INVESTIGATE. When unsure, escalate toward Cooper.

## Gating rules (what always needs the user)

- Sending any email / message
- Moving money, paying, disputing a charge
- Deleting (vs archiving) anything
- Rotating/revoking production credentials
- Anything requiring a phone call or 2FA/passkey login

## Pitfalls

- gog `--all` paginates but stdout cap truncates JSON in the code tool — write to file.
- `gog gmail` commands timing out: this is usually the macOS Keychain blocking access to the token. Ask Cooper to run `gog auth list` locally and click "Always Allow". Do NOT use headless UI/CDP browser navigation into gmail.com as a workaround for blocked tokens; `gog` is the required tool for Gmail interactions. See `references/gog-macos-keychain-blocker.md`.
- **Browser Automation limits**: Financial websites (e.g., Zelle inside Bank of America) may actively sandbox inputs populated via CDP and block transfers/submissions. Limit agent tasks to "read/investigate", pre-populate the submission, and prompt the user that they must push the finalizing "Send" or "Confirm" button manually on their local device to avoid transaction blocks.
- gog step-2 remote auth can hang; run it `background=true` + `notify_on_complete`.
- Account picker defaults to the wrong Google account — verify `hd=` in the redirect URL
  matches the intended account before exchanging.
- **Bank "Status: Declined" fraud alerts** are usually already-handled by the bank → HANDOFF.
- **For bank login automation**, do not stop at "needs Cooper to log in" if credentials exist in the shared 1Password vault. Try himitsu → 1Password service account → live Chrome CDP.
- **CDP Authentication Path**: When investigating financial items, prefer Cooper's existing live local Chrome via CDP (127.0.0.1:9222) over remote headless browsers.
- **SMS MFA Retrieval**: If an SMS OTP is required during a CDP flow, MacOS local Messages DB (`~/Library/Messages/chat.db`) or BlueBubbles can be queried to securely fetch authentication codes autonomously.
- **Keyring/Keychain Blocks**: Background CLI processes (like `gog`) can hang indefinitely if macOS requires a keychain prompt. If the agent gets stuck loading credentials, investigate whether a UI prompt is blocking the process and ask the user to clear it from an interactive terminal (e.g., `gog auth list` -> "Always Allow").
  change.
- Some cm.xyz mail is really To: me@cooperm.com (forwarded) — note true recipient.

## Cross-references

- `gog` skill — all Gmail/Calendar/Drive CLI operations
- `~/.hermes/email-triage-dod-framework.md` — the DoD contract
- `templates/email-triage-dod.feature` — reusable Gherkin acceptance-test template
- `references/troubleshooting.md` - Troubleshooting guide and pitfalls for CLI hanging, macOS Keychain, and Money Movement limits.
- `references/dependency-mapping.md` — dependency categories, account clusters, and Cooper-intervention batching
- `references/live-chrome-cdp-financial-login.md` — live local Chrome + 1Password service-account pattern for banks/passkeys
- **MFA/OTP Codes:** When using macOS, retrieve incoming SMS/iMessage verification codes directly via the `imessage` skill script: `~/.hermes/skills/apple/imessage/scripts/extract_otp_chat_db.py`.
- `references/bluebubbles-otp-for-logins.md` — retrieving SMS OTPs via BlueBubbles/local Messages during approved login flows
- `scripts/live-chrome-cdp.js` — privacy-preserving localhost CDP helper for new tabs/eval/screenshots/close
