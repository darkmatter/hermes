# BlueBubbles OTP Retrieval for Login Automation

Use this when Cooper has approved login automation for an account that sends SMS OTPs and BlueBubbles is running locally on the Mac.

## Core lesson

For Cooper's authenticated workflows, OTP can be partially automated without asking him to manually paste the code:

1. Use live local Chrome CDP to reach the OTP challenge.
2. Trigger the OTP only when it is an authentication-only step and Cooper has approved the account/login workflow.
3. Retrieve the incoming SMS through BlueBubbles or the local Messages database.
4. Enter the OTP via CDP.
5. Stop at the next security/device-trust/account-decision gate.

This improves autonomy while preserving gates around device trust, fraud answers, money movement, account setting changes, and other security decisions.

## Observed setup

- BlueBubbles app process: `/Applications/BlueBubbles.app/...`
- Local server listens on port `1234`.
- Config DB: `~/Library/Application Support/bluebubbles-server/config.db`
- Server password is stored in the `config` table under key `password`.
- API auth works with query parameter `?password=<server-password>` or `?guid=<server-password>`.
- Server info endpoint: `http://127.0.0.1:1234/api/v1/server/info?password=...`
- Local Messages DB: `~/Library/Messages/chat.db`

Do not print the BlueBubbles password, phone numbers, OTP contents beyond the current workflow, or unrelated message text.

## Preferred retrieval path
## Querying local Messages Database directly
When BlueBubbles API is complex or fails, prefer querying the local `chat.db` with SQLite directly. Be robust with the Apple epoch times.

```python
import sqlite3, datetime, re, os
DB=os.path.expanduser('~/Library/Messages/chat.db')

def conv_date(x):
    if x is None: return None
    try: x=int(x)
    except: return None
    if x > 10**15: ts = x/1e9 + 978307200
    elif x > 10**12: ts = x/1e6 + 978307200
    else: ts = x + 978307200
    return datetime.datetime.fromtimestamp(ts)

con=sqlite3.connect(DB)
con.row_factory=sqlite3.Row
rows=con.execute('''
  SELECT message.ROWID, message.date, message.text, handle.id as handle
  FROM message LEFT JOIN handle ON message.handle_id=handle.ROWID
  WHERE message.is_from_me=0
  ORDER BY message.date DESC LIMIT 30
''').fetchall()

for r in rows:
    txt=r['text'] or ''
    # extract code safely
```

## Safe OTP flow

1. Confirm the page is an OTP request for the account being worked.
2. Select the least risky delivery channel, usually text message over phone call, if the page already presents both.
3. Click the send/request code control only if the current task authorizes authentication continuation.
4. Poll Messages for a recent OTP.
5. Enter the code into the current browser tab.
6. Stop at the next gate and summarize the page state.

## Gates after OTP

Still requires Cooper approval:
- Remember/trust this computer/device decisions.
- Fraud Yes/No answers.
- Security questions.
- Account setting changes.
- Payments, transfers, disputes, renewals, purchases.
- Sending messages or submitting forms with external consequence.

## Bank of America pilot result

Validated path:
- BoA credentials came from 1Password service-account access.
- Live Chrome CDP submitted username/password.
- BoA requested text/phone authorization code.
- After Cooper said BlueBubbles was available, the agent selected text and requested the code.
- The OTP was found in local Messages and entered via CDP.
- Next blocker: BoA security preference asked whether to remember/trust this computer.
- Agent stopped at the device-trust decision.

## Gherkin

```gherkin
Scenario: Continue an approved login through SMS OTP using BlueBubbles
  Given Cooper has approved login automation for the account
  And the account page is asking for an SMS authorization code
  And BlueBubbles or the local Messages database is available
  When the agent requests the SMS code
  And the agent reads only recent incoming messages matching an OTP pattern
  And the agent enters the OTP into the live Chrome tab
  Then the agent reports the post-OTP page state
  And the agent stops before any device-trust, fraud, payment, or account-setting decision
  And the agent records the new blocker on the kanban card
```
