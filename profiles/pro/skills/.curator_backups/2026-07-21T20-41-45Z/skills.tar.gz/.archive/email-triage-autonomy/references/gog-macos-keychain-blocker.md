# Gog CLI: macOS Keychain Blocker

**Symptom:**
When running `gog` commands (e.g., `gog gmail list ...`) in the background, the command hangs and eventually times out with an error similar to:
`keyring connection timed out after 10s ... (macOS Keychain may be waiting for a permission prompt)`

**Cause:**
The `gog` CLI is attempting to access the OAuth token stored in the macOS Keychain, but macOS is surfacing a secure UI dialog asking the user to approve the access. Because the agent executes commands in the background, it cannot see or interact with this UI.

**Resolution / Pitfall:**
1. Do NOT attempt to switch to file-backed keyrings (`GOG_KEYRING_BACKEND=file`) as a workaround, because the specific tokens have already been persisted to the macOS Keychain.
2. Instead, ask the user to open a foreground terminal on their machine and run:
   `gog auth list`
3. Instruct them to click **"Always Allow"** on the macOS permission prompt. This permanently whitelists the binary, and all subsequent background `gog` commands will authenticate seamlessly.