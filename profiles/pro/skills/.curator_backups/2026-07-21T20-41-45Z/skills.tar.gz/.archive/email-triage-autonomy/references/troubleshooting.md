# Email Triage Troubleshooting & Pitfalls

## macOS Keychain Blocking CLI Tools
If `gog` or other CLI authentication-dependent tools hang or time out during background execution, they are likely being blocked by a macOS Keychain permission prompt that the agent cannot see.
**Fix:** Do not attempt complex browser automation to work around the CLI. Instead, ask the user to run the tool's authentication command (e.g., `gog auth list`) in a foreground local terminal and click "Always Allow" on the keychain dialog. 

## Financial Logins & Browser Automation
- **Do NOT** use headless browsers or remote Camofox for banking/passkeys.
- **DO** use the user's Live Chrome profile via CDP (`127.0.0.1:9222`) using the helper `~/.hermes/scripts/live-chrome-cdp.js` for authenticated continuity.
- **Zelle & Money Movement Guardrails:** Even with Live Chrome, banks (like Bank of America) tightly fingerprint automated inputs and injection speeds. If you automate a Zelle transfer sequence, prepare the draft/UI but **HANDOFF** to the human for final form submission. Otherwise, the bank's anti-fraud will block the submission ("Unable to schedule your payment").