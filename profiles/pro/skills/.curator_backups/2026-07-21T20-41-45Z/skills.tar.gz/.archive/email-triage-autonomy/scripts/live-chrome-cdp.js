#!/usr/bin/env node
// Live local Chrome CDP helper for authenticated workflows.
// Connects only to localhost. Does not list tab URLs/titles by default.

const CDP = require('/tmp/cdp-tools/node_modules/chrome-remote-interface');
const fs = require('fs');

const PORT = Number(process.env.CHROME_CDP_PORT || '9222');
const HOST = process.env.CHROME_CDP_HOST || '127.0.0.1';

async function version() {
  const v = await CDP.Version({host: HOST, port: PORT});
  console.log(JSON.stringify({Browser: v.Browser, ProtocolVersion: v['Protocol-Version'], webSocketDebuggerUrl: !!v.webSocketDebuggerUrl}, null, 2));
}

async function targets() {
  const list = await CDP.List({host: HOST, port: PORT});
  console.log(JSON.stringify({count: list.length, types: list.reduce((m,t)=>{m[t.type]=(m[t.type]||0)+1; return m}, {})}, null, 2));
}

async function newtab(url='about:blank') {
  const target = await CDP.New({host: HOST, port: PORT, url});
  console.log(JSON.stringify({id: target.id, type: target.type, url: target.url}, null, 2));
}

async function navigate(url) {
  if (!url || !/^https?:\/\//.test(url)) throw new Error('navigate requires an http(s) URL');
  const target = await CDP.New({host: HOST, port: PORT, url: 'about:blank'});
  const client = await CDP({host: HOST, port: PORT, target: target.id});
  const {Page, Runtime} = client;
  await Page.enable();
  await Runtime.enable();
  await Page.navigate({url});
  await Page.loadEventFired();
  const title = await Runtime.evaluate({expression: 'document.title', returnByValue: true});
  const href = await Runtime.evaluate({expression: 'location.href', returnByValue: true});
  console.log(JSON.stringify({id: target.id, title: title.result.value, url: href.result.value}, null, 2));
  await client.close();
}

async function evalOn(targetId, expression) {
  if (!targetId || !expression) throw new Error('eval requires <targetId> <expression>');
  const client = await CDP({host: HOST, port: PORT, target: targetId});
  const {Runtime} = client;
  await Runtime.enable();
  const result = await Runtime.evaluate({expression, returnByValue: true, awaitPromise: true});
  console.log(JSON.stringify(result.result.value ?? result.result.description ?? null, null, 2));
  await client.close();
}

async function screenshot(targetId, outPath) {
  if (!targetId || !outPath) throw new Error('screenshot requires <targetId> <outPath>');
  const client = await CDP({host: HOST, port: PORT, target: targetId});
  const {Page} = client;
  await Page.enable();
  const shot = await Page.captureScreenshot({format: 'png', captureBeyondViewport: false});
  fs.writeFileSync(outPath, Buffer.from(shot.data, 'base64'));
  console.log(JSON.stringify({path: outPath, bytes: fs.statSync(outPath).size}, null, 2));
  await client.close();
}

async function closeTarget(targetId) {
  if (!targetId) throw new Error('close requires <targetId>');
  await CDP.Close({host: HOST, port: PORT, id: targetId});
  console.log(JSON.stringify({closed: targetId}, null, 2));
}

async function main() {
  const [cmd, ...args] = process.argv.slice(2);
  if (cmd === 'version') return await version();
  if (cmd === 'targets') return await targets();
  if (cmd === 'newtab') return await newtab(args[0] || 'about:blank');
  if (cmd === 'navigate') return await navigate(args[0]);
  if (cmd === 'eval') return await evalOn(args[0], args.slice(1).join(' '));
  if (cmd === 'screenshot') return await screenshot(args[0], args[1]);
  if (cmd === 'close') return await closeTarget(args[0]);
  console.error(`Usage:
  live-chrome-cdp.js version
  live-chrome-cdp.js targets
  live-chrome-cdp.js newtab [url]
  live-chrome-cdp.js navigate <https-url>
  live-chrome-cdp.js eval <targetId> <js-expression>
  live-chrome-cdp.js screenshot <targetId> <out.png>
  live-chrome-cdp.js close <targetId>`);
  process.exit(2);
}
main().catch(e => { console.error(e && e.stack || String(e)); process.exit(1); });
