# Live Chrome CDP for Financial / Passkey Login Workflows

Use this when Cooper wants the agent to log into authenticated sites (banks, financial accounts, passkey/2FA-heavy services) as part of email triage or account follow-up.

## Core lesson

For banks and passkey-heavy sites, prefer Cooper's existing live local Chrome via CDP over remote Camofox/session transfer.

Why:
- local Chrome has Cooper's real device trust, passkeys, extensions, and saved sessions
- avoids brittle cookie/profile transfer
- lets the agent reuse the same browser Cooper uses while still routing all sensitive actions through explicit approval gates

## Expected setup

- Chrome exposes CDP on localhost, typically `127.0.0.1:9222`.
- Use a helper such as `~/.hermes/scripts/live-chrome-cdp.js` or the skill script `scripts/live-chrome-cdp.js`.
- Default helper behavior should be privacy-preserving: show target counts, not existing tab URLs/titles, unless Cooper explicitly asks.
- Open new tabs for account workflows where possible.

## Credential path

Use himitsu + 1Password service account:

```bash
himitsu exec op-service-account/token -- bash -lc '
  OP_SERVICE_ACCOUNT_TOKEN="$TOKEN" op vault list --format json
'
```

Important: `himitsu exec op-service-account/token` exposes the token as env var `TOKEN`; pass it to `op` as `OP_SERVICE_ACCOUNT_TOKEN="$TOKEN"`. Do not print token values.

Observed useful secret/item pattern:
- himitsu paths: `op-service-account/id`, `op-service-account/token`
- 1Password CLI: `op` v2 service account mode
- vault: `private`
- Bank of America item title may be `secure.bankofamerica.com`

## Safe login sequence

1. Navigate live Chrome directly to the official typed URL, not an email link.
2. Fetch credential from 1Password via service account without printing secrets.
3. Fill username/password into the live Chrome tab via CDP.
4. Submit login.
5. Stop at the first challenge requiring Cooper's presence: OTP, passkey, phone approval, security question, fraud prompt, or account decision.
6. Comment progress on the kanban card, including exactly what worked and what blocker remains.

## Gates

Allowed before asking Cooper:
- open a new tab to an official URL
- fill saved username/password from 1Password
- submit the initial login form
- read the resulting page state after login attempt
- summarize non-secret page state

Must stop and ask Cooper before:
- sending an OTP code to phone/email
- entering an OTP if Cooper has not explicitly supplied/approved it
- answering security questions
- clicking fraud Yes/No choices
- disputing charges
- transferring or paying money
- downloading sensitive statements unless requested
- changing contact, security, autopay, or account settings

## Bank of America pilot result

The path was validated beyond first challenge:
- live Chrome CDP at `127.0.0.1:9222` worked
- 1Password service-account credential retrieval worked
- BoA username/password were filled and accepted
- BlueBubbles/local Messages OTP retrieval worked after Cooper authorized it
- BoA SMS authorization code was requested, read from local Messages, and entered via CDP
- next blocker: BoA Security Preference page asked whether to remember/trust this computer
- agent stopped at the device-trust decision

This means username/password + SMS OTP login can be automated for approved flows. Device-trust,
passkeys, phone approvals, security questions, fraud answers, payment/money movement, and account
settings remain Cooper-gated decisions.

## Gherkin

```gherkin
Scenario: Bank login reaches the next human decision safely
  Given Cooper has approved use of live local Chrome via CDP
  And a matching login item exists in the shared 1Password vault
  When the agent opens the official bank URL in a new tab
  And fills and submits the username and password from 1Password
  And SMS OTP is available through BlueBubbles for this approved login flow
  Then the agent may request and enter the OTP
  And the agent must report whether authentication progressed
  And the agent must stop before device-trust, fraud, payment, transfer, or settings decisions
  And the agent must comment the blocker on the kanban card
```
