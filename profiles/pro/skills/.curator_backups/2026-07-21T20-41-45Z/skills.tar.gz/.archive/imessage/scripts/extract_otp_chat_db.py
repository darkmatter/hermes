#!/usr/bin/env python3
"""
Extracts recent OTP/verification codes directly from macOS Messages local database.
Useful when `imsg` CLI is missing or bluebubbles API isn't immediately accessible.
Apple's absolute time starts 2001-01-01 (978307200 Unix epoch).
"""
import sqlite3, time, re, os, datetime

DB = os.path.expanduser('~/Library/Messages/chat.db')

def conv_date(x):
    if x is None: return None
    try: x = int(x)
    except: return None
    if x > 10**15: ts = x/1e9 + 978307200
    elif x > 10**12: ts = x/1e6 + 978307200
    else: ts = x + 978307200
    return datetime.datetime.fromtimestamp(ts)

def get_recent_code(max_age_minutes=15):
    if not os.path.exists(DB):
        return None
    
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    try:
        rows = con.execute('''
          SELECT message.ROWID, message.date, message.text, handle.id as handle
          FROM message LEFT JOIN handle ON message.handle_id=handle.ROWID
          WHERE message.is_from_me=0
          ORDER BY message.date DESC LIMIT 50
        ''').fetchall()
    finally:
        con.close()

    now = datetime.datetime.now()
    for r in rows:
        txt = r['text'] or ''
        dt = conv_date(r['date'])
        if not dt: continue
        age = (now - dt).total_seconds()
        
        if age < max_age_minutes * 60:
            # Look for typical 6-digit codes
            m = re.search(r'\b(\d{6})\b', txt)
            if m:
                return {'code': m.group(1), 'from': r['handle'], 'age_seconds': int(age), 'text': txt}
    return None

if __name__ == '__main__':
    res = get_recent_code()
    if res:
        print(f"CODE={res['code']}")
        print(f"FROM={res['from']}")
    else:
        print("NO_CODE_FOUND")
        exit(1)
