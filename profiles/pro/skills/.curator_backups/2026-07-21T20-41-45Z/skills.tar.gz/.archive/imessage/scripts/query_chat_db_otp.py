#!/usr/bin/env python3
"""
Native fallback for extracting recent OTPs/MFA codes directly from macOS Messages chat.db 
when the `imsg` CLI is unavailable. This reads the SQLite db locally without extra permissions 
(assuming terminal has Full Disk Access).
"""
import sqlite3, os, datetime, re, sys

DB = os.path.expanduser('~/Library/Messages/chat.db')
if not os.path.exists(DB):
    print("chat.db not found")
    sys.exit(1)

def conv_date(x):
    if not x: return None
    try: x = int(x)
    except: return None
    # Apple absolute time starts 2001-01-01 (978307200 unix)
    # Recent macOS uses nanoseconds, older used seconds
    if x > 10**15: ts = x/1e9 + 978307200
    elif x > 10**12: ts = x/1e6 + 978307200
    else: ts = x + 978307200
    return datetime.datetime.fromtimestamp(ts)

con = sqlite3.connect(DB)
con.row_factory = sqlite3.Row
rows = con.execute('''
    SELECT message.text, handle.id as handle, message.date
    FROM message LEFT JOIN handle ON message.handle_id=handle.ROWID
    WHERE message.is_from_me=0
    ORDER BY message.date DESC LIMIT 50
''').fetchall()
con.close()

now = datetime.datetime.now()
found = False

for r in rows:
    txt = r['text'] or ''
    dt = conv_date(r['date'])
    age = (now - dt).total_seconds() if dt else 999999
    
    # Check messages from the last 15 minutes
    if age < 15 * 60:
        m = re.search(r'\b(\d{4,8})\b', txt)
        # Match common OTP verbiage
        if m and any(kw in txt.lower() for kw in ['code', 'auth', 'bank', 'verify', 'otp', 'security']):
            print(f"CODE={m.group(1)} | FROM={r['handle']} | AGE_SEC={int(age)}")
            print(f"TEXT={txt}")
            found = True
            break # Print newest match only

if not found:
    print("NO_RECENT_CODE_FOUND")
    sys.exit(0)
