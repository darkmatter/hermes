#!/usr/bin/env python3
import sqlite3, datetime, re, os, sys

def conv_date(x):
    if not x: return None
    try: x = int(x)
    except: return None
    ts = (x/1e9 if x>10**15 else x/1e6 if x>10**12 else x) + 978307200
    return datetime.datetime.fromtimestamp(ts)

DB=os.path.expanduser('~/Library/Messages/chat.db')
if not os.access(DB, os.R_OK):
    print('chat.db not readable. Needs Full Disk Access.')
    sys.exit(1)

con=sqlite3.connect(DB)
con.row_factory=sqlite3.Row
rows=con.execute('''
  SELECT message.date, message.text, handle.id as handle
  FROM message LEFT JOIN handle ON message.handle_id=handle.ROWID
  WHERE message.is_from_me=0 ORDER BY message.date DESC LIMIT 30
''').fetchall()

keyword = sys.argv[1].lower() if len(sys.argv) > 1 else ''
for r in rows:
    txt = r['text'] or ''
    dt = conv_date(r['date'])
    if not dt or (datetime.datetime.now()-dt).total_seconds() > 900: continue
    hay = (txt + ' ' + str(r['handle'])).lower()
    if keyword in hay or re.search(r'\b\d{6}\b', txt):
        m = re.search(r'\b(\d{4,8})\b', txt)
        if m:
            print(f"CODE={m.group(1)}\nFROM={r['handle']}")
            sys.exit(0)
print('NO_CODE_FOUND')
sys.exit(2)
