---
name: imessage
description: Send and receive iMessages/SMS via the imsg CLI on macOS.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [iMessage, SMS, messaging, macOS, Apple]
prerequisites:
  commands: [imsg]
---

# iMessage

Use `imsg` to read and send iMessage/SMS via macOS Messages.app.

## Missing CLI Fallback
If the `imsg` CLI is missing on the machine, you can run the bundled Python fallback script to parse the `chat.db` database manually and retrieve verification codes natively:
```bash
python3 ~/.hermes/skills/apple/imessage/scripts/query_chat_db_otp.py
```

- **macOS** with Messages.app signed in
- Install: `brew install steipete/tap/imsg`
- Grant Full Disk Access for terminal (System Settings → Privacy → Full Disk Access)
- Grant Automation permission for Messages.app when prompted

## When to Use

- User asks to send an iMessage or text message
- Reading iMessage conversation history
- Checking recent Messages.app chats
- Sending to phone numbers or Apple IDs

## When NOT to Use

- Telegram/Discord/Slack/WhatsApp messages → use the appropriate gateway channel
- Group chat management (adding/removing members) → not supported
- Bulk/mass messaging → always confirm with user first

## Troubleshooting

- **`imsg` not installed**: Fall back to direct SQLite queries against `~/Library/Messages/chat.db` for read-only operations (if the terminal has Full Disk Access). See the OTP script as an example.
- **BlueBubbles available**: If BlueBubbles is running natively instead of `imsg`, it listens locally. `lsof -iTCP -sTCP:LISTEN | grep bluebubbles` or find the `config.db` to extract the password, then curl the local API (e.g., `http://127.0.0.1:1234/api/v1/ping?password=...`). Note this approach requires reading the API password out of the SQLite config.

## Quick Reference

### Watch for New Messages

```bash
imsg watch --chat-id 1 --attachments
```

### Extracting OTPs
If `imsg` is unavailable or you need to poll for 2FA/OTP codes from the local database directly, use the provided `scripts/extract_otp_chat_db.py` script.

## Service Options

```bash
# By chat ID
imsg history --chat-id 1 --limit 20 --json

# With attachments info
imsg history --chat-id 1 --limit 20 --attachments --json
```

### Send Messages

```bash
# Text only
imsg send --to "+14155551212" --text "Hello!"

# With attachment
imsg send --to "+14155551212" --text "Check this out" --file /path/to/image.jpg

# Force iMessage or SMS
imsg send --to "+14155551212" --text "Hi" --service imessage
imsg send --to "+14155551212" --text "Hi" --service sms
```

### Watch for New Messages

```bash
imsg watch --chat-id 1 --attachments
```

### Extracting OTPs
If `imsg` is unavailable or you need to poll for 2FA/OTP codes from the local database directly, use the provided `scripts/extract_otp_chat_db.py` script.

## Service Options
If `imsg` is unavailable (e.g. not installed), you can read incoming SMS/OTPs directly from the macOS Messages database using sqlite3, avoiding the need for external tooling:
```bash
# NOTE: Apple timestamp is seconds/nanoseconds since Jan 1, 2001. Add 978307200 for Unix epoch.
sqlite3 ~/Library/Messages/chat.db "SELECT text FROM message WHERE is_from_me=0 ORDER BY date DESC LIMIT 10;"
```

### Retrieve OTPs/Codes Programmatically
If `imsg` is unavailable (or you need a silent/fast OTP pull), you can read the local Messages DB directly if the terminal has Full Disk Access:
```bash
python3 ~/.hermes/skills/apple/imessage/scripts/get_latest_otp.py "bank"
```
This looks for 4-8 digit codes in the last 15 minutes of incoming messages.

## Service Options

- `--service imessage` — Force iMessage (requires recipient has iMessage)
- `--service sms` — Force SMS (green bubble)
- `--service auto` — Let Messages.app decide (default)

## Rules

1. **Always confirm recipient and message content** before sending
2. **Never send to unknown numbers** without explicit user approval
3. **Verify file paths** exist before attaching
4. **Don't spam** — rate-limit yourself

## Example Workflow

User: "Text mom that I'll be late"

```bash
# 1. Find mom's chat
imsg chats --limit 20 --json | jq '.[] | select(.displayName | contains("Mom"))'

# 2. Confirm with user: "Found Mom at +1555123456. Send 'I'll be late' via iMessage?"

# 3. Send after confirmation
imsg send --to "+1555123456" --text "I'll be late"
```
