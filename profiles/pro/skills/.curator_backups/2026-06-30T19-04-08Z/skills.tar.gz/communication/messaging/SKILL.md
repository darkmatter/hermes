---
name: messaging
description: "Terminal-based messaging — email via Himalaya CLI (IMAP/SMTP) and iMessage via BlueBubbles API or osascript fallback. Use when reading/sending email from terminal, or sending iMessages when the imsg CLI is unavailable."
version: 1.0.0
metadata:
  hermes:
    tags: [email, imessage, messaging, CLI, IMAP, SMTP, BlueBubbles]
---

# Terminal Messaging

Two messaging channels operated from the terminal:

1. **Email (Himalaya CLI)** — IMAP/SMTP email client for reading, listing,
   searching, composing, and managing emails. Separate from the Hermes Email
   gateway adapter.

2. **Email (gog CLI)** — alternative Gmail access via Google API. Use when
   Himalaya is not installed or OAuth-based Gmail access is needed. See the
   `gog-cli-troubleshooting` skill (ops) for full command reference and
   batch operations.

3. **iMessage (BlueBubbles / osascript)** — sending iMessages when the `imsg`
   CLI is unavailable. BlueBubbles API (preferred), osascript fallback.

---

## Part 1: Email via Himalaya CLI

Himalaya is a CLI email client that manages emails from the terminal using
IMAP, SMTP, Notmuch, or Sendmail backends.

### Prerequisites

1. Himalaya CLI installed (`himalaya --version` to verify)
2. Config at `~/.config/himalaya/config.toml`
3. IMAP/SMTP credentials configured

```bash
# Install
brew install himalaya  # macOS
# Or: curl -sSL https://raw.githubusercontent.com/pimalaya/himalaya/master/install.sh | PREFIX=~/.local sh
```

For full configuration (Gmail, iCloud, OAuth2, folder aliases) see
`references/himalaya-configuration.md`.

> **Critical folder alias pitfall:** Use `folder.aliases.X` (plural, dotted
> keys) in v1.2.0+. The old `[accounts.NAME.folder.alias]` (singular) form is
> silently ignored, causing save-to-Sent failures and duplicate emails on
> retry. See configuration reference for details.

### Hermes Integration Notes

- **Reading, listing, searching, moving, deleting** — work directly through the terminal tool
- **Composing/replying/forwarding** — piped input (`cat << EOF | himalaya template send`) is recommended for reliability
- Use `--output json` for structured output
- The `himalaya account configure` wizard requires interactive input — use PTY mode: `terminal(command="himalaya account configure", pty=true)`

### Common Operations

```bash
# List folders
himalaya folder list

# List emails in INBOX
himalaya envelope list

# Search
himalaya envelope list from john@example.com subject meeting

# Read email by ID
himalaya message read 42

# Write new email (non-interactive — use this from Hermes)
cat << 'EOF' | himalaya template send
From: you@example.com
To: recipient@example.com
Subject: Test Message

Hello from Himalaya!
EOF

# Reply
himalaya template reply 42 | sed 's/^$/\nYour reply text here\n/' | himalaya template send

# Move to folder
himalaya message move 42 "Archive"

# Delete
himalaya message delete 42

# Attachments
himalaya attachment download 42 --dir ~/Downloads
```

For rich emails with attachments, inline images, and multipart messages,
see `references/himalaya-message-composition.md` (MML syntax).

### Multiple Accounts

```bash
himalaya --account work envelope list
```

---

## Part 2: iMessage via BlueBubbles / osascript

When the `imsg` CLI is not installed, use BlueBubbles API (preferred) or
osascript (fallback) to send iMessages.

### Method 1 — BlueBubbles API (preferred)

BlueBubbles runs locally and exposes a REST API.

```bash
# 1. Verify BlueBubbles is running
lsof -iTCP -sTCP:LISTEN | grep -i bluebubbles

# 2. Get the API password from the SQLite config
sqlite3 ~/Library/Application\ Support/BlueBubbles/config.db \
  "SELECT value FROM config WHERE key='password'"

# 3. Send a message
curl -s "http://127.0.0.1:1234/api/v1/message/text?password=<PASSWORD>" \
  -X POST -H "Content-Type: application/json" \
  -d '{"chatGuid":"iMessage;-;+131****7076","text":"Hello!","ddwc":true,"subject":"","method":"private-api"}'
```

The port number may vary — check `lsof` output for the actual port.

### Method 2 — osascript (fallback)

Use AppleScript to drive Messages.app directly. **Critical** — you must
reference the iMessage service by its `service type`, NOT by name.

```bash
osascript -e '
tell application "Messages"
    set theService to 1st service whose service type = iMessage
    set theBuddy to buddy "+155****1212" of theService
    send "message text" to theBuddy
end tell'
```

### Pitfalls

- **`Invalid key form (-10002)`** — Caused by referencing the service by string name instead of `service type`. Use `1st service whose service type = iMessage`.
- **BlueBubbles port mismatch** — The default port is 1234 but may differ. Always check `lsof` output first.
